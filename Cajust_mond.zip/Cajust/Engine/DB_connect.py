# -*- coding: utf-8 -*-
"""
Created on Wed May  8 10:36:28 2019

@author: tanmay.sidhu
"""


import pandas as pd
import mysql.connector as mariadb
print("here")
def DB_connect(query):
    try:
        mariadb_connection=mariadb.connect(host='evs01cpa008', user='root', password='cajust1234', database='cajust')
        cursor=mariadb_connection.cursor()
        cursor.execute(query)
    except mariadb.Error as error:
        print("Error{}".format(error))
    sql_data=pd.DataFrame(cursor.fetchall())
    sql_data.columns=cursor.column_names

    mariadb_connection.commit()
    cursor.close()
    return sql_data
def DB_connect_many(query,df_list):
    mariadb_connection=mariadb.connect(host='evs01cpa008', user='root', password='cajust1234', database='cajust',use_pure=True)
    cursor=mariadb_connection.cursor(buffered=True)
    try:
        cursor.executemany(query,df_list)
    except mariadb.Error as error:
        mariadb_connection.rollback()
        print("Error{}".format(error))
    mariadb_connection.commit()
    cursor.close()
#a=[["8503", "0.9790874586483933", "0.9950712705489425", "0.9979619565217391", "1.0", "1.0213592168573746", "1.0049531421486408", "1.0020422055820286", "1", "3084.0", "726.377952", "301.0", 'Yes', 'Yes']]
#DB_connect_many("INSERT INTO cajust.ca_req_outputdetails(CaReqDetailID,Div_GTR_PAF,Div_NTR_PAF,Div_PR_PAF,Div_NSAF,SCR_GTR_NSAF,SCR_NTR_NSAF,SCR_PR_NSAF,SCR_PAF,AddC_GTR_CASH,AddC_NTR_CASH,AddC_PR_CASH,Handled_on_PayDate,Multiple_Case) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",a)
#DB_connect_many("Insert into ca_req_OUTPUTdetails(CAReqDetailID,Div_GTR_PAF,Div_NTR_PAF,Div_PR_PAF,Div_NSAF,SCR_GTR_NSAF,SCR_NTR_NSAF,SCR_PR_NSAF,SCR_PAF,AddC_GTR_CASH,AddC_NTR_CASH,AddC_PR_CASH,Handled_on_PayDate,Multiple_Case) values (8503,0.979087458648393,0.995071270548942,0.997961956521739,1,1.02135921685737,1.00495314214864,1.00204220558202,1,3084,726.377952,301,'Yes','Yes')")
#a=DB_connect("SELECT  a.PayDateJapan,a.PayDateKorea FROM preferences AS a \
#                                                       JOIN ca_req_input AS b ON a.PreferenceID=b.PreferenceID \
#                                                       JOIN ca_req_inputdetails AS c ON c.CARequestID=b.CARequestID \
#                                                       LIMIT 1",no_query="one")
#DB_connect("SELECT a.ExDate,a.IdentifierMappingID,c.EventType,d.CountryCode as EventCurrency,e.CountryCode as LocalCurrency,a.EventAmount,a.OfferPrice \
#                                                ,a.TermOldShares,a.TermNewShares,a.SpunOffStock,a.SpunOffCash,a.BuybackShares,a.PriceExT1,a.FxExT1,a.PayDate,a.PayDatePrice,a.PayDatePriceT1, \
#                                                a.PayDateFx,a.PayDateFxT1,a.FrankingPercent,a.IncomePercent,a.WHTType,a.REIT,a.Comments,(case \
#                                                when a.WHTType = 'Flat' then 10 \
#                                                ELSE m.taxrate \
#                                                END) AS TaxRate \
#                                                from ca_req_inputdetails as a \
#                                                join identifiermapping as b on a.IdentifierMappingID = b.MappingID \
#                                                join eventhandlingmaster as c on c.EventHandlingID = a.EventTypeID  \
#                                                left join countrymaster as d on d.CountryID = a.EventCurrID \
#                                                left join countrymaster as e on e.CountryID = a.LocalCurrID \
#                                                left join (select a.TaxName,a.CountryID,b.EffectiveFromDate,b.EffectiveToDate,b.TaxRate,b.REIT,b.ISActive \
#                                                from cajust.countrytaxrate_wht as a \
#                                                join cajust.countrytaxrate_details as b on a.TaxID = b.TaxID) as m on a.WHTType = m.TaxName and a.LocalCurrID = m.CountryId and a.REIT = m.REIT \
#                                                where a.IsActiveReq = 1 \
#                                                ")  
##cursor.execute ("UPDATE factset.output SET IndexLevel=%s WHERE CalDate=%s",data["Index_Series"].tail(1),current_date.strftime("%Y-%m-%d"))
