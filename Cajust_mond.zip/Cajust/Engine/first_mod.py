# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 11:13:40 2019

@author: tanmay.sidhu
"""

print("Hi this is first module")