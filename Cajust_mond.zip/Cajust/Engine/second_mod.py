# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 11:14:34 2019

@author: tanmay.sidhu
"""
import requests
import DB_connect
import pandas as pd
result_df=DB_connect.DB_connect("SELECT b.CARequestID,c.ISIN,c.SEDOL,c.BBGTicker,c.RIC,d.EventType,a.* from cajust.ca_req_outputdetails AS a \
                                JOIN cajust.ca_req_inputdetails AS b ON a.CaReqDetailID = b.CaReqDetailID \
                                JOIN cajust.identifiermapping AS c ON b.IdentifierMappingID = c.MappingID \
                                JOIN cajust.eventhandlingmaster AS d ON b.EventTypeID = d.EventHandlingID \
                                ")
user_input="csv"
api_endpoint="url"
if "csv"==user_input:
    data_cs=result_df.to_csv()
    requests.post(api_endpoint,data=data_cs)
if "json"==user_input:        
    data_js=result_df.to_json(orient='records')
    requests.post(api_endpoint,json=data_js)
#if "xml"==user_input:
#    
#    def to_xml(df, filename=None, mode='w'):
#        def row_to_xml(row):
#            xml = ['<item>']
#            for i, col_name in enumerate(row.index):
#                xml.append('  <field name="{0}">{1}</field>'.format(col_name, row.iloc[i]))
#            xml.append('</item>')
#            return '\n'.join(xml)
#        res = '\n'.join(df.apply(row_to_xml, axis=1))
#
#        if filename is None:
#            return res
#        with open(filename, mode) as f:
#            f.write(res)
#
#    pd.DataFrame.to_xml = to_xml
#    data_xm=result_df.to_xml()
#requests.post("url",data=)

URL = "http://maps.googleapis.com/maps/api/geocode/json"
location = "delhi technological university"
PARAMS = {'address':location}
r = requests.get(url = URL, params = PARAMS)
data = r.json() 
print(data)