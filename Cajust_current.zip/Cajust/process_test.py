# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 14:31:48 2019

@author: tanmay.sidhu
"""

import multiprocessing
import os
from functools import partial
import core_var
import DB_connect
#def square(n):
#    print("Worker process id for {0}: {1}".format(n, os.getpid()))
#    return n*n


#if __name__=="__main__":
    
mylist=[1,2,3,4,5]
p=multiprocessing.Pool()

q1=DB_connect.DB_connect("select carequestID from ca_req_input where flagprocessed=1")
q1_val=q1.values[0]
q2=DB_connect.DB_connect("SELECT f.CARequestID,a.CAReqDetailID,a.ExDate,a.IdentifierMappingID,c.EventType,d.CountryCode as EventCurrency,e.CountryCode as LocalCurrency,a.EventAmount,a.OfferPrice \
                         ,a.TermOldShares,a.TermNewShares,a.SpunOffStock,a.SpunOffCash,a.BuybackShares,a.PriceExT1,a.FxExT1,a.PayDate,a.PayDatePrice,a.PayDatePriceT1, \
                         a.PayDateFx,a.PayDateFxT1,a.FrankingPercent,a.IncomePercent,a.WHTType,a.REIT,a.Comments,(case \
                        when a.WHTType = 'Flat' then f.WHTFlatRate \
                        ELSE m.taxrate \
                        END) AS TaxRate  \
                        from ca_req_inputdetails as a \
                        join identifiermapping as b on a.IdentifierMappingID = b.MappingID \
                        JOIN ca_req_input AS f ON f.CARequestID = a.CARequestID AND f.FlagProcessed=1 \
                        join eventhandlingmaster as c on c.EventHandlingID = a.EventTypeID \
                        left join countrymaster as d on d.CountryID = a.EventCurrID \
                        left join countrymaster as e on e.CountryID = a.LocalCurrID \
                        left join (select a.TaxName,a.CountryID,b.EffectiveFromDate,b.EffectiveToDate,b.TaxRate,b.REIT,b.ISActive \
                        from countrytaxrate_wht as a  \
                        join countrytaxrate_details as b on a.TaxID = b.TaxID) as m on a.WHTType = m.TaxName and a.LocalCurrID = m.CountryId and a.REIT = m.REIT \
                        where a.IsActiveReq = 1 AND f.CARequestID ={}".format(q1_val))

b=p.map(db_co,)

result=p.map(DB_connect.Db_connect(q1),list(DB_connect.Db_connect(q2))
print(result)