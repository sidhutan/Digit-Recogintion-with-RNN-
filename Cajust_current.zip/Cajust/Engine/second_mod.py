# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 11:14:34 2019

@author: tanmay.sidhu
"""
import requests
import DB_connect
import os
import pylogger
logA=pylogger.loggy()

def file_generation():
    result_df=DB_connect.DB_connect("SELECT b.CARequestID,c.ISIN,c.SEDOL,c.BBGTicker,c.RIC,d.EventType,a.* from ca_req_outputdetails AS a \
                                        JOIN cajust.ca_req_inputdetails AS b ON a.CaReqDetailID = b.CaReqDetailID \
                                        JOIN cajust.identifiermapping AS c ON b.IdentifierMappingID = c.MappingID \
                                        JOIN cajust.eventhandlingmaster AS d ON b.EventTypeID = d.EventHandlingID")
    user_input="csv" #query from deep db as per caRequestDbID
    api_endpoint="http://172.16.4.124:8000/api/v1/cajust/CARequestOutputViewSet/FileHandling/1/"
    if "csv"==user_input:
        try:
            result_df.to_csv("fin_output.csv")
            files={"file": open(os.getcwd()+"\\fin_output.csv",'rb')}
        #    headers={'Content-type':'multipart/form-data'}
            a=requests.put(api_endpoint,files=files)
            print("csv"+a.text)
            logA.info("csv"+a.text)
        except:
            logA.error("csv file generation error")
    #    requests.request(put,api_endpoint,data=data_cs,multi)
        
    if "json"==user_input:
        try:
            result_df.to_json("fin_j.txt",orient="records")
            files={"file" : open(os.getcwd()+"\\fin_j.txt","rb")}
        #    files = {"file":open(r'C:\Users\tanmay.sidhu\Documents\Cajust\Engine\',"rb")}
            b=requests.put(api_endpoint,files=files)
            print("json"+b.text)
            logA.info("json"+b.text)
        except:
            logA.error("json file generation error")
    #    requests.post(api_endpoint,json=data_js)
#if "xml"==user_input:
#    
#    def to_xml(df, filename=None, mode='w'):
#        def row_to_xml(row):
#            xml = ['<item>']
#            for i, col_name in enumerate(row.index):
#                xml.append('  <field name="{0}">{1}</field>'.format(col_name, row.iloc[i]))
#            xml.append('</item>')
#            return '\n'.join(xml)
#        res = '\n'.join(df.apply(row_to_xml, axis=1))
#
#        if filename is None:
#            return res
#        with open(filename, mode) as f:
#            f.write(res)
#
#    pd.DataFrame.to_xml = to_xml
#    data_xm=result_df.to_xml()
#requests.post("url",data=)
file_generation()
