# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 11:34:24 2019

@author: tanmay.sidhu
"""

# -*- coding: utf-8 -*-
"""
Created on Mon May 13 10:34:08 2019

@author: tanmay.sidhu

"""
import pandas as pd
import DB_connect
import pylogger
logA=pylogger.loggy()
#a=DB_connect.DB_connect('select a.ExDate,a.IdentifierMappingIDMappingID,c.EventType,d.CountryCode as EventCurrency,e.CountryCode as LocalCurrency,a.EventAmount,a.OfferPrice \
#                                            ,a.TermOldShares,a.TermNewShares,a.SpunOffStock,a.SpunOffCash,a.BuybackShares,a.PriceExT1,a.FxExT1,a.PayDate,a.PayDatePrice,a.PayDatePriceT1, \
#                                            a.PayDateFx,a.PayDateFxT1,a.FrankingPercent,a.IncomePercent,a.WHTType,a.REIT,a.Comments,m.TaxRate from ca_req_inputdetails as a \
#                                            join IdentifierMappingIDmapping as b on a.IdentifierMappingIDMappingID = b.MappingID \
#                                            join eventhandlingmaster as c on c.EventHandlingID = a.EventTypeID \
#                                            left join countrymaster as d on d.CountryID = a.EventCurrID \
#                                            left join countrymaster as e on e.CountryID = a.LocalCurrID \
#                                            left join (select a.TaxName,a.CountryID,b.EffectiveFromDate,b.EffectiveToDate,b.TaxRate,b.REIT,b.ISActive \
#                                            from cajust.countrytaxrate_wht as a \
#                                            join cajust.countrytaxrate_details as b on a.TaxID = b.TaxID) as m on a.WHTType = m.WHTType and a.LocalCurrID = m.CountryId and a.REIT = m.REIT \
#                                            where a.IsActiveReq = 1')
class conf:
    def __init__(self,a):
        
        
        """DF sql_data is a universe of Input client uploading"""
        # self.sql_data=DB_connect.DB_connect("SELECT a.CAReqDetailID,a.ExDate,a.IdentifierMappingID,c.EventType,d.CountryCode as EventCurrency,e.CountryCode as LocalCurrency,a.EventAmount,a.OfferPrice ,a.TermOldShares,a.TermNewShares,a.SpunOffStock,a.SpunOffCash,a.BuybackShares,a.PriceExT1,a.FxExT1,a.PayDate,a.PayDatePrice,a.PayDatePriceT1,a.PayDateFx,a.PayDateFxT1,a.FrankingPercent,a.IncomePercent,a.WHTType,a.REIT,a.Comments,m.TaxRate from ca_req_inputdetails as a join identifiermapping as b on a.IdentifierMappingID = b.MappingID JOIN ca_req_input AS f ON f.CARequestID = a.CARequestID join eventhandlingmaster as c on c.EventHandlingID = a.EventTypeID left join countrymaster as d on d.CountryID = a.EventCurrID left join countrymaster as e on e.CountryID = a.LocalCurrID left join (select c.TaxName,c.CountryID,b.EffectiveFromDate,b.EffectiveToDate,b.TaxRate,b.REIT,b.ISActive, c.WHTType from cajustdb.countrytaxrate_wht as c join cajustdb.countrytaxrate_details as b on c.TaxID = b.TaxID ) as m on a.WHTType = m.WHTType and a.LocalCurrID = m.CountryId and a.REIT = m.REIT and a.ExDate between m.EffectiveFromDate and m.EffectiveToDate where a.IsActiveReq = 0")
#        self.sql_data=pd.read_csv(r"C:\Users\tanmay.sidhu\Documents\Cajust\Engine\sql_data_deep.csv")
        
#            final_used
#        self.sql_data=DB_connect.DB_connect("SELECT a.CAReqDetailID,a.ExDate,a.IdentifierMappingID,c.EventType,d.CountryCode as EventCurrency,e.CountryCode as LocalCurrency,a.EventAmount,a.OfferPrice \
#                                                ,a.TermOldShares,a.TermNewShares,a.SpunOffStock,a.SpunOffCash,a.BuybackShares,a.PriceExT1,a.FxExT1,a.PayDate,a.PayDatePrice,a.PayDatePriceT1, \
#                                                a.PayDateFx,a.PayDateFxT1,a.FrankingPercent,a.IncomePercent,a.WHTType,a.REIT,a.Comments,(case \
#                                                when a.WHTType = 'Flat' then 10 \
#                                                ELSE m.taxrate \
#                                                END) AS TaxRate \
#                                                from ca_req_inputdetails as a \
#                                                join identifiermapping as b on a.IdentifierMappingID = b.MappingID \
#                                                join eventhandlingmaster as c on c.EventHandlingID = a.EventTypeID  \
#                                                left join countrymaster as d on d.CountryID = a.EventCurrID \
#                                                left join countrymaster as e on e.CountryID = a.LocalCurrID \
#                                                left join (select a.TaxName,a.CountryID,b.EffectiveFromDate,b.EffectiveToDate,b.TaxRate,b.REIT,b.ISActive \
#                                                from cajust.countrytaxrate_wht as a \
#                                                join cajust.countrytaxrate_details as b on a.TaxID = b.TaxID) as m on a.WHTType = m.TaxName and a.LocalCurrID = m.CountryId and a.REIT = m.REIT \
#                                                where a.IsActiveReq = 1 \
#                                                ")
        self.sql_data=pd.read_csv("sql_data_working.csv")

#        self.sql_data=DB_connect.DB_connect('select A.UserName,B.EventType,C.LocalCurrency,D.Taxrate,X.* from cainput as X join causer as A on A.UserId = X.UserId join eventtypemaster as B on B.eventtypeid = x.eventtypeid join countrymaster as C on C.CountryId = x.countryid join countrytaxrate_wht as D on D.CountryID = X.CountryId')
#        self.sql_data=DB_connect.DB_connect('''SELECT a.CAReqDetailID,a.ExDate,a.IdentifierMappingID,c.EventType,d.CountryCode as EventCurrency,e.CountryCode as LocalCurrency,
#                                            a.EventAmount,a.OfferPrice ,a.TermOldShares,a.TermNewShares,a.SpunOffStock,a.SpunOffCash,a.BuybackShares,a.PriceExT1,a.FxExT1,
#                                            a.PayDate,a.PayDatePrice,a.PayDatePriceT1,a.PayDateFx,a.PayDateFxT1,a.FrankingPercent,a.IncomePercent,a.WHTType,a.REIT,a.Comments,
#                                            m.TaxRate,p.* from ca_req_inputdetails as a 
#                                            join identifiermapping as b on a.IdentifierMappingID = b.MappingID 
#                                            JOIN ca_req_input AS f ON f.CARequestID = a.CARequestID 
#                                            join eventhandlingmaster as c on c.EventHandlingID = a.EventTypeID 
#                                            left join countrymaster as d on d.CountryID = a.EventCurrID 
#                                            left join countrymaster as e on e.CountryID = a.LocalCurrID 
#                                            join preferences as p on p.PreferenceID = f.PreferenceID
#                                            left join (select c.TaxName,c.CountryID,b.EffectiveFromDate,b.EffectiveToDate,b.TaxRate,b.REIT,b.ISActive, c.WHTType 
#                                            from catooldevserverdb.countrytaxrate_wht as c join catooldevserverdb.countrytaxrate_details as b on c.TaxID = b.TaxID ) 
#                                            as m on a.WHTType = m.WHTType and a.LocalCurrID = m.CountryId and a.REIT = m.REIT and a.ExDate 
#                                            between m.EffectiveFromDate and m.EffectiveToDate where a.IsActiveReq = 0 and f.CARequestID ={}'''.format(a))
#         self.sql_preference_data=DB_connect.DB_connect("SELECT  a.PayDateJapan,a.PayDateKorea FROM preferences AS a \
#                                                        JOIN ca_req_input AS b ON a.PreferenceID=b.PreferenceID \
#                                                        JOIN ca_req_inputdetails AS c ON c.CARequestID=b.CARequestID \
#                                                        LIMIT 1")

#        self.PayDateJapan=self.sql_data.PayDateJapan.values[0]
#        self.PayDateKorea=self.sql_data.PayDateKorea.values[0]
        self.PayDateJapan=0
        self.PayDateKorea=1
#        self.sql_data.to_csv("sql_data.csv")
        if self.PayDateJapan==False and self.PayDateKorea==False:
            print("J_F_K_F")
            logA.info("Case J_F_K_F")
            self.sql_data["CombinedEx"]=self.sql_data["IdentifierMappingID"].astype(str)+"_"+self.sql_data["ExDate"].astype(str)
            self.d_final_combinedEx=self.sql_data[self.sql_data["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedEx=self.sql_data[~self.sql_data["CombinedEx"].duplicated(keep=False)]
            self.d_final_combinedPay=pd.DataFrame()
#            self.d_final_combinedPay =None
            self.nd_final_combinedPay = pd.DataFrame()
        elif self.PayDateJapan==False and self.PayDateKorea==True:
            print("J_F_K_T")
            logA.info("Case J_F_K_T")
            self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["KR"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"CombinedPay"]=self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["KR"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"IdentifierMappingID"].astype(str)+"_"+self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["KR"]))&(self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"PayDate"].astype(str)
            self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["KR"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"CombinedEx"]=self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["KR"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"IdentifierMappingID"].astype(str)+"_"+self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["KR"]))&(self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"ExDate"].astype(str)
            self.sql_data_p=self.sql_data.loc[~self.sql_data["CombinedPay"].isnull()]
            self.sql_data_e=self.sql_data.loc[~self.sql_data["CombinedEx"].isnull()]
#            self.sql_data.to_csv("try.csv")
            self.d_final_combinedPay=self.sql_data_p[self.sql_data_p["CombinedPay"].duplicated(keep=False)]
            self.d_final_combinedEx=self.sql_data_e[self.sql_data_e["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedPay_tmp=self.sql_data_p[~(self.sql_data_p["CombinedPay"].duplicated(keep=False))]
            self.nd_final_combinedPay=self.nd_final_combinedPay_tmp[(self.nd_final_combinedPay_tmp["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))&(self.nd_final_combinedPay_tmp["LocalCurrency"].isin(["KR"]))]
            self.nd_final_combinedEx_tmp=self.sql_data_e[~self.sql_data_e["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedEx=self.nd_final_combinedEx_tmp[~((self.nd_final_combinedEx_tmp["LocalCurrency"].isin(["KR"]))& (self.nd_final_combinedEx_tmp["EventType"].isin(["Special Cash Dividend","Cash Dividend"])))]
        elif self.PayDateJapan==True and self.PayDateKorea==False:
            print("J_T_K_F")
            logA.info("Case J_T_K_F")
            self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"CombinedPay"]=self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"IdentifierMappingID"].astype(str)+"_"+self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["JP"]))&(self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"PayDate"].astype(str)
            self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"CombinedEx"]=self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"IdentifierMappingID"].astype(str)+"_"+self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["JP"]))&(self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"ExDate"].astype(str)
            self.sql_data_p=self.sql_data.loc[~self.sql_data["CombinedPay"].isnull()]
            self.sql_data_e=self.sql_data.loc[~self.sql_data["CombinedEx"].isnull()]
            self.d_final_combinedPay=self.sql_data_p[self.sql_data_p["CombinedPay"].duplicated(keep=False)]
            self.d_final_combinedEx=self.sql_data_e[self.sql_data_e["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedPay_tmp=self.sql_data_p[~(self.sql_data_p["CombinedPay"].duplicated(keep=False))]
            self.nd_final_combinedPay=self.nd_final_combinedPay_tmp[(self.nd_final_combinedPay_tmp["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))&(self.nd_final_combinedPay_tmp["LocalCurrency"].isin(["JP"]))]
            self.nd_final_combinedEx_tmp=self.sql_data_e[~self.sql_data_e["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedEx=self.nd_final_combinedEx_tmp[~((self.nd_final_combinedEx_tmp["LocalCurrency"].isin(["JP"]))& (self.nd_final_combinedEx_tmp["EventType"].isin(["Special Cash Dividend","Cash Dividend"])))]
        elif self.PayDateKorea==True and self.PayDateJapan==True:
            print("J_T_K_T")
            logA.info("Case J_T_K_T")
            self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["KR","JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"CombinedPay"]=self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["KR","JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"IdentifierMappingID"].astype(str)+"_"+self.sql_data.loc[(self.sql_data["LocalCurrency"].isin(["KR","JP"]))&(self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"])),"PayDate"].astype(str)
            self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["KR","JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"CombinedEx"]=self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["KR","JP"])) & (self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"IdentifierMappingID"].astype(str)+"_"+self.sql_data.loc[~((self.sql_data["LocalCurrency"].isin(["KR","JP"]))&(self.sql_data["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))),"ExDate"].astype(str)
#            self.sql_data.to_csv("final_sql.csv")
            self.sql_data_p=self.sql_data.loc[~self.sql_data["CombinedPay"].isnull()]
            self.d_final_combinedPay=self.sql_data_p[self.sql_data_p["CombinedPay"].duplicated(keep=False)]
#            self.d_final_combinedPay.to_csv("final_d_final_combinedPay.csv")
            self.sql_data_e=self.sql_data.loc[~self.sql_data["CombinedEx"].isnull()]
            self.d_final_combinedEx=self.sql_data_e[self.sql_data_e["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedPay_tmp=self.sql_data_p[~(self.sql_data_p["CombinedPay"].duplicated(keep=False))]
            self.nd_final_combinedPay=self.nd_final_combinedPay_tmp[(self.nd_final_combinedPay_tmp["EventType"].isin(["Special Cash Dividend","Cash Dividend"]))&(self.nd_final_combinedPay_tmp["LocalCurrency"].isin(["KR","JP"]))]
            self.nd_final_combinedEx_tmp=self.sql_data_e[~self.sql_data_e["CombinedEx"].duplicated(keep=False)]
            self.nd_final_combinedEx=self.nd_final_combinedEx_tmp[~((self.nd_final_combinedEx_tmp["LocalCurrency"].isin(["JP","KR"]))& (self.nd_final_combinedEx_tmp["EventType"].isin(["Special Cash Dividend","Cash Dividend"])))]

    

        self.d_final_combinedPay.to_csv("d_final_combinedPay.csv")
        self.d_final_combinedEx.to_csv("d_final_combinedEx.csv")
        self.nd_final_combinedPay.to_csv("nd_final_combinedPay.csv")
        self.nd_final_combinedEx.to_csv('nd_final_combinedEx.csv')
#        nd_event_types=self.nd_final_combinedEx["EventType"].str.to_list()
    
        """DF sql_cash_div  has all the cash and special cash entries"""
        """DF sql_cash_div_except has only exceptions""" 
        """DF sql_cash_div_ex_excep has excluded all the exceptions"""
        self.sql_cash_div=self.nd_final_combinedEx[self.nd_final_combinedEx["EventType"].isin(["Special Cash Dividend","Cash Dividend"])]
        #using country code instead of currency
        self.sql_cash_div_except=self.sql_cash_div[self.sql_cash_div["LocalCurrency"].isin(["AU"])]
#        self.sql_cash_div_except.to_csv("nd_final_combinedEx_cash_div_except_AU_CD_SCD.csv")
        self.sql_cash_div_ex_excep=self.sql_cash_div[~self.sql_cash_div["LocalCurrency"].isin(["AU"])]
#        self.sql_cash_div_ex_excep.to_csv("nd_final_combinedEx_cash_div_EXCLUDING_except_AU.csv")
        """Others"""
        """DF sql_others other CA other than cash Dividend and Special cash"""
        """DF sql_other_except has only Exceptions"""
        """DF sql_other_ex_except has excluted all Exceptions"""
        self.sql_others=self.nd_final_combinedEx[~self.nd_final_combinedEx["EventType"].isin(["Special Cash Dividend","Cash Dividend"])]
        self.sql_others.to_csv("sql_others.csv")

        
#    return nd_event_types
        
        #using country code instead of currency
        
#a=conf()
#sql_data=a.sql_data
#sql_data["ExDate"]=pd.to_datetime(sql_data["ExDate"])

#print(type(sql_data["ExDate"].values[0]))
#print(a.sql_others)
#print(a.sql_s_cash_div)
