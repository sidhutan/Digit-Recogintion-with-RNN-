# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 23:06:27 2019

@author: Tanmay.Sidhu
"""



import random
import string
import warnings
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import warnings
warnings.filterwarnings('ignore')
#from nltk.chat.eliza import eliza_chat
from kella_assistant import speak
from supported_file2 import eliza_chat
import time
#from server import socketio, handle_message, handle_my_custom_event
from nltk.chat.util import Chat, reflections
import nltk
from nltk.stem import WordNetLemmatizer
from flask_socketio import SocketIO, emit
from flask import Flask

is_bot_handling = False
bot_reference = eliza_chat()

app=Flask(__name__)
app.config['SECRET_KEY']='secret!'
socketio=SocketIO(app)
    
@socketio.on('message')
def handle_message(message):
    print('received message: ' + message)
    if message == 'hello, bot':
        initial_speech()
        return True
    handle_user_intent(message)
    #handle_my_custom_event("ACK")
    #return message
    
@socketio.on('sermessage')
def handle_my_custom_event(json):
    #emit(json)
    emit('sermessage', json)
    
#@socketio.on('connect')
#def test_connect():
#    print("client connected")
#    initial_speech()
#from flask_socketio import send, emit
##Receiving messages from client
#@socketio.on('message')
#def handle_message(message):
#    handle_my_custom_event('text')
#    print('received message: ' + message)
##send messages to client
#@socketio.on('my event')
#def handle_my_custom_event(text):
#    emit('my response', text)

#eliza_chat()
#from nltk.chat.zen import zen_chat
#zen_chat()

#nltk.download('popular',quiet=True)

f=open('C:/Users/tanmay.sidhu/Desktop/evs_products.txt','r',errors='ignore')
raw=f.read()
raw=raw.lower()

sent_tokens=nltk.sent_tokenize(raw)
word_tokens=nltk.word_tokenize(raw)


lemmer=nltk.stem.WordNetLemmatizer()

def LemTokens(tokens):
    return [lemmer.lemmatize(token) for token in tokens]
remove_punct_dict=dict((ord(punct),None) for punct in string.punctuation)

def LemNormalize(text):
    return LemTokens(nltk.word_tokenize(text.lower().translate(remove_punct_dict)))

GREETING_INPUTS = ("hello", "hi", "greetings", "sup", "what's up","hey",)
GREETING_RESPONSES = ["hi", "hey", "*nods*", "hi there", "hello", "I am glad! You are talking to me"]

GREETING_INPUTS_1=('how are you','how are you feeling today')
GREETING_RESPONSES_1=["Good, thanks for asking",'Good']

    
def greeting(sentence):
#    chat = Chat(pairs, reflections)
#    chat.converse()
    
    """If user's input is a greeting, return a greeting response"""
    for word in sentence.split():
        if word.lower() in GREETING_INPUTS:
            a=random.choice(GREETING_RESPONSES)
#            handle_my_custom_event(a)
#            speak(a)
            return a
        elif word.lower() in GREETING_INPUTS_1:
            b=random.choice(GREETING_RESPONSES_1)
#            handle_my_custom_event(b)
#            speak(b)
            return b
#            chat = Chat(pairs, reflections)
#            chat.converse()
def response(user_response):
    global is_bot_handling
    robo_response=''
    sent_tokens.append(user_response)
    TfidfVec = TfidfVectorizer(tokenizer=LemNormalize, stop_words='english')
#    print("TfidfVec",TfidfVec)
    tfidf = TfidfVec.fit_transform(sent_tokens)
#    print("tfidf","tfidf")
    vals = cosine_similarity(tfidf[-1], tfidf)
    idx=vals.argsort()[0][-2]
    flat = vals.flatten()
    flat.sort()
    req_tfidf = flat[-2]
    if(req_tfidf==0):
        is_bot_handling = True
        print("bot is handling this user response")
        bot_response = bot_reference.respond(user_response);
        print(bot_response)
        handle_my_custom_event(bot_response)
#        speak(bot_response)
        return robo_response
    else:
        robo_response = robo_response+sent_tokens[idx]
        print(robo_response)
        handle_my_custom_event(robo_response)
        speak(robo_response)
        return robo_response

def initial_speech():
    #print("ROBO: My name is Robo. I can have general conversation or can talk about AI. If you want to exit, type/say Bye!")
    print('Hi, Welcome to Evalueserve Customer Experience Zone!')
    handle_my_custom_event('Hi, Welcome to Evalueserve Customer Experience Zone!')
    speak('Hi, Welcome to Evalueserve Customer Experience Zone!')
    print('Is this is your first visit? If yes, please create a new account. In case, you are already registered with us, please login.')
    handle_my_custom_event('Is this is your first visit? If yes, please create a new account. In case, you are already registered with us, please login.')
    speak('Is this is your first visit? If yes, please create a new account. In case, you are already registered with us, please login.')
    return True
    print('There are 4 broad Level Solution we provide')
    handle_my_custom_event('There are 4 broad Level Solution we provide')
    speak('There are 4 broad Level Solutions we provide')
    print('1: Consulting\
          2: Knowledge Services\
          3: Analytics\
          4: Digital Platforms')
    handle_my_custom_event('1: Consulting\
          2: Knowledge Services\
          3: Analytics\
          4: Digital Platforms')
    print("which one are you interested in ?")
    handle_my_custom_event('which one are you interested in ?')
    speak("which one are you interested in ?")
    


def handle_user_intent(user_response):
    global is_bot_handling
    if user_response == 'evs':
        is_bot_handling = False
        print("Exiting evs bot")
        return True
    if user_response=='bye':
        is_bot_handling = False
        print('Feel free to ask for a call back from one of our experts in this area.')
        handle_my_custom_event('Feel free to ask for a call back from one of our experts in this area.')
        speak('Feel free to ask for a call back from one of our experts in this area.')
        print("Bye, see you soon!")
        handle_my_custom_event("Bye, see you soon!")
        speak("Bye, see you soon!")
        return True
    if is_bot_handling:
        response(user_response)
        sent_tokens.remove(user_response)
    if user_response=='what is your name?':
        print("Hi, I am EVS Assistant, nice to meet you!")
        handle_my_custom_event('Hi, I am EVS Assistant, nice to meet you!')
        speak('Hi, I am EVS Assistant, nice to meet you!')
        return True
    if user_response=="how are you?":
        print("I am good, thanks for asking")
        handle_my_custom_event('I am good, thanks for asking')
        speak("I am good, thanks for asking")
        return True
    if (user_response==''):
        print("Please say something")
        handle_my_custom_event("Please say something")
        speak("Please say something")
        return True
    if(user_response!='bye'):
#        print("I am here")
        if(user_response=='thanks' or user_response=='thank you' ):
#            flag=False
            print("ROBO:You are welcome..")
            handle_my_custom_event('You are welcome..')
            speak("You are Welcome")
        else:
            if(greeting(user_response)!=None):
                wishes=greeting(user_response)
#                print("ROBO: "+greeting(user_response))
                handle_my_custom_event(wishes)
                speak(wishes)
            else:
                print("ROBO: ",end="")
                response(user_response)
#                handle_my_custom_event(response(user_response))
                sent_tokens.remove(user_response)
#    else:
#        print('Feel free to ask for a call back from one of our experts in this area.')
#        handle_my_custom_event('Feel free to ask for a call back from one of our experts in this area.')
#        speak('Feel free to ask for a call back from one of our experts in this area.')
#        print("Bye, see you soon!")
#        handle_my_custom_event("Bye, see you soon!")
#        speak("Bye, see you soon!")

if __name__=='__main__':
    socketio.run(app)
#    initial_speech()
#init_server()