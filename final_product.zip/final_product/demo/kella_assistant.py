# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser
#import time


engine=pyttsx3.init('sapi5')
voices=engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
#    pass
#speak("Hey Tanmay, how are you ? how was your day?")
#speak("I am Dexter sir. How may I help you? ")
def wishMe():
    hour=int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("A very Good Afternoon! Tanmay")
    elif hour<=12 and hour<18:
        speak("A very Good Afternoon! Tanmay")
    else:
        speak("Good Evening! Tanmay")
    speak("I am kella, your assistant. How may I help you ?")

def takecommand():
    r=sr.Recognizer()
    with sr.Microphone() as source:
        print(">>>Listening>>>>")
#        r.pause_threshold=1
        audio=r.listen(source)
#        print("audio",audio)
    try:
        print("Recognizing...")
#        start=time.time()
        query=r.recognize_google(audio,language='en-in')
#        end=time.time()
#        print((end-start)/60.0)
        print("User said: {}".format(query))
    except Exception:
        print("Say that again please..")
        return "None"
    return query
if __name__=="__main__":
    wishMe()
    while True:
        query=takecommand().lower()
        if "how are you" in query:
            speak("I am good sir, thanks for asking")
        elif "what's up" in query:
            speak("Nothing much, just checking some background tasks, you say")
        elif 'wikipedia' in query:
            speak("Searching wikipedia...")
            query=query.replace("Wikipedia","")
            result=wikipedia.summary(query,sentences=2)
            speak("According to wikipedia")
            print(result)
            speak(result)
        elif "open youtube" in query:
            webbrowser.open("youtube.com")
        elif 'open iknow portal' in query:
            webbrowser.open("http://iknow/")
        elif 'weather' in query:
            webbrowser.open("https://www.google.com/search?q=how+the+today's+weather&rls=com.microsoft:en-US:IE-SearchBox&ie=UTF-8&oe=UTF-8&sourceid=ie7&gws_rd=ssl")
        elif "good" in query:
            speak("Great! thanks for asking")
        elif "name" in query:
            speak("I am Axel, your personal assistant")
        elif "sorry" in query:
            speak("Never mind")
        elif "code" in query:
            speak("Mr Tanmay Singh Sidhu")
        elif "play music" in query:
            webbrowser("youtube.com")
        elif "selection" in query or 'Election' in query or 'collection' in query:
            speak("What should be the selection universe")
        elif "msc" in query or "MSP" in query or "Miss universe" in query:
#            speak("M S C I")
#            speak("selection")
            speak("Let me select top 10 stocks with high return type")
        elif "bye" in query:
            speak("See you sir")
            exit()
            
        
