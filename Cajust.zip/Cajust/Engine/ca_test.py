# -*- coding: utf-8 -*-
"""
Created on Wed May 22 10:46:30 2019

@author: tanmay.sidhu
"""

import pandas as pd
dir(pd)
preference=pd.read_csv(r'C:\Users\tanmay.sidhu\Documents\preference.csv')
print(preference["Japan"].index[1])
