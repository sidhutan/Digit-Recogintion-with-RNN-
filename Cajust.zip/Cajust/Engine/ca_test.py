# -*- coding: utf-8 -*-
"""
Created on Wed May 22 10:46:30 2019

@author: tanmay.sidhu
"""

def fn_demo(a):
    if a==10:
        print("Hey")
    elif a==20:
        print("Bye")
