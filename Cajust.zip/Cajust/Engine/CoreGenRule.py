# -*- coding: utf-8 -*-
"""
Created on Mon May 13 10:36:20 2019

@author: tanmay.sidhu
"""
#import core_var as variables
import pylogger
logA=pylogger.loggy.logger
#lg=logging.getlg()
class rule_divisor:
    def __init__(self):
        try:
            logA.info("Divisor is Initiated")
            #statements
            logA.info("Divisor Initiation is Succesfully done")
            pass
        except:
            logA.Error("Divisor Initialisation has FAILED")
            pass
    def cash_dividend(self):
        try:
            logA.info("Cash Dividend Calculation is Initiated")
            pass
        except:
            logA.Error("Cash Dividend Calculation has FAILED")
            pass
    def special_cash_dividend(self):
        try:
            logA.info("Special Cash Dividend Calculation is Initiated")
            pass
        except:
            logA.Error("Special Cash Dividend Calculation has FAILED")
            pass
    def stock_dividend(self):
        try:
            logA.info("Stock Dividend Calculation is Initiated")
            pass
        except:
            logA.Error("Stock Dividend Calculation has FAILED")
            pass
    def stock_split(self):
        try:
            logA.info("Stock Dividend Calculation is Initiated")
            pass
        except Exception as e:
            logA.Error(e)
            logA.Error("Special Cash Dividend Calculation is Initiated")
            pass
    def rights_issue(self):
        try:
            logA.info("Rights Issue Calculation is Initiated")
            pass
        except:
            logA.Error("Rights Issue Calculation is Initiated")
            pass

check=rule_divisor()
check.cash_dividend()