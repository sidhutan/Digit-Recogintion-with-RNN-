# -*- coding: utf-8 -*-
"""
Created on Wed May  8 10:36:28 2019

@author: tanmay.sidhu
"""


import pandas as pd

import mysql.connector as mariadb
print("here")
def DB_connect():  
    mariadb_connection=mariadb.connect(host='evs01cpa008', user='root', password='cajust1234', database='cajust')
    cursor=mariadb_connection.cursor()
#    cursor.execute(query)
    try:
        cursor.execute('select * from countrymaster')
    except mariadb.Error as error:
        print("Error{}".format(error))
    sql_data=pd.DataFrame(cursor.fetchall())
   
    sql_data.columns=cursor.column_names
#    sql_data.to_csv("db.csv")
    cursor.close()
#    return sql_data

#    for i,j in cursor:
#        print(i,j)


DB_connect()
