# -*- coding: utf-8 -*-
"""
Created on Mon Sep 16 21:31:26 2019

@author: tanmay.sidhu
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 11:14:34 2019

@author: tanmay.sidhu
"""
import requests
import DB_connect
import os
import pylogger
logA=pylogger.loggy()

def file_generation(ID):
    
    result_df=DB_connect.DB_connect("SELECT b.CARequestID,c.ISIN,c.SEDOL,c.BBGTicker,c.RIC,d.EventType,a.* from ca_req_outputdetails AS a left JOIN ca_req_inputdetails AS b ON a.CaReqDetailID = b.CaReqDetailID left JOIN identifiermapping AS c ON b.IdentifierMappingID = c.MappingID left JOIN eventhandlingmaster AS d ON b.EventTypeID = d.EventHandlingID where b.CARequestID={}".format(ID))
    #ID=int(result_df["CARequestID"].values[0])
    
    query="INSERT INTO ca_req_output (CARequestID,CreatedBy,CreatedDate) VALUES ({0},'System',now())".format(ID)
    DB_connect.DB_connect_in(query)

    result_df1=DB_connect.DB_connect("SELECT CAOutputId FROM cajustdb.ca_req_output where CARequestID={}".format(ID))
    OutID=int(result_df1["CAOutputId"].values[0])

    user_input="csv" #query from deep db as per caRequestDbID
#    query_used by deep
#    SELECT b.CARequestID,c.ISIN,c.SEDOL,c.BBGTicker,c.RIC,d.EventType,a.* from ca_req_outputdetails AS a JOIN ca_req_inputdetails AS b ON a.CaReqDetailID = b.CaReqDetailID JOIN identifiermapping AS c ON b.IdentifierMappingID = c.MappingID JOIN eventtypemaster AS d ON b.EventTypeID = d.EventHandling
    api_endpoint="http://172.16.4.124:8000/api/v1/cajust/CARequestOutputViewSet/FileHandling/{}/".format(OutID)
    print(api_endpoint)
    if "csv"==user_input:
        try:
            result_df.to_csv("fin_output{0}_".format(ID)+".csv")
            files={"file": open(os.getcwd()+"\\fin_output{0}_".format(ID)+".csv",'rb')}
        #    headers={'Content-type':'multipart/form-data'}
            a=requests.put(api_endpoint,files=files)
            print("csv"+a.text)
            logA.info("csv"+a.text)
        except:
            logA.error("csv file generation error")
    #    requests.request(put,api_endpoint,data=data_cs,multi)
        
    if "json"==user_input:
        try:
            result_df.to_json("fin_j.txt",orient="records")
            files={"file" : open(os.getcwd()+"\\fin_j.txt","rb")}
        #    files = {"file":open(r'C:\Users\tanmay.sidhu\Documents\Cajust\Engine\',"rb")}
            b=requests.put(api_endpoint,files=files)
            print("json"+b.text)
            logA.info("json"+b.text)
        except:
            logA.error("json file generation error")
    #    requests.post(api_endpoint,json=data_js)

 