# -*- coding: utf-8 -*-
"""
Created on Wed May  8 10:36:28 2019

@author: tanmay.sidhu
"""


import pandas as pd
import mysql.connector as mariadb
print("here")
def DB_connect(query):
    try:
        print("localhost")
        mariadb_connection=mariadb.connect(host='localhost', user='root', password='evs@123', database='cajustdb',auth_plugin='mysql_native_password')
        cursor=mariadb_connection.cursor()
        cursor.execute(query)
    except mariadb.Error as error:
        print("Error{}".format(error))
    sql_data=pd.DataFrame(cursor.fetchall())
    sql_data.columns=cursor.column_names
    mariadb_connection.commit()
    cursor.close()
    return sql_data
def DB_connect_many(query,df_list):
    mariadb_connection=mariadb.connect(host='localhost', user='root', password='evs@123', database='cajustdb',auth_plugin='mysql_native_password',use_pure=True)
    cursor=mariadb_connection.cursor(buffered=True)
    try:
        cursor.executemany(query,df_list)
    except mariadb.Error as error:
        mariadb_connection.rollback()
        print("Error{}".format(error))
    mariadb_connection.commit()
    cursor.close()
def DB_connect_in(query):
    try:
        mariadb_connection=mariadb.connect(host='localhost', user='root', password='evs@123', database='cajustdb',auth_plugin='mysql_native_password',use_pure=True)
        cursor=mariadb_connection.cursor()
        cursor.execute(query)
    except mariadb.Error as error:
        print("Error{}".format(error))
    mariadb_connection.commit()
    cursor.close()
