# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 23:06:27 2019

@author: Tanmay.Sidhu
"""


import io
import random
import string
import warnings
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import warnings
warnings.filterwarnings('ignore')
#from nltk.chat.eliza import eliza_chat
from kella_assistant import speak
from supported_file2 import eliza_chat
import time


#eliza_chat()
#from nltk.chat.zen import zen_chat
#zen_chat()
from nltk.chat.util import Chat, reflections


import nltk
from nltk.stem import WordNetLemmatizer
#nltk.download('popular',quiet=True)

f=open('C:/Users/tanmay.sidhu/Desktop/evs_products.txt','r',errors='ignore')
raw=f.read()
raw=raw.lower()

sent_tokens=nltk.sent_tokenize(raw)
word_tokens=nltk.word_tokenize(raw)


lemmer=nltk.stem.WordNetLemmatizer()

def LemTokens(tokens):
    return [lemmer.lemmatize(token) for token in tokens]
remove_punct_dict=dict((ord(punct),None) for punct in string.punctuation)

def LemNormalize(text):
    return LemTokens(nltk.word_tokenize(text.lower().translate(remove_punct_dict)))

GREETING_INPUTS = ("hello", "hi", "greetings", "sup", "what's up","hey",)
GREETING_RESPONSES = ["hi", "hey", "*nods*", "hi there", "hello", "I am glad! You are talking to me"]

GREETING_INPUTS_1=('how are you','how are you feeling today')
GREETING_RESPONSES_1=["Good, thanks for asking",'Good']

    
def greeting(sentence):
#    chat = Chat(pairs, reflections)
#    chat.converse()
    
    """If user's input is a greeting, return a greeting response"""
    for word in sentence.split():
        if word.lower() in GREETING_INPUTS:
            speak(random.choice(GREETING_RESPONSES))
            return random.choice(GREETING_RESPONSES)
        elif word.lower() in GREETING_INPUTS_1:
            speak(random.choice(GREETING_RESPONSES_1))
            return random.choice(GREETING_RESPONSES_1)
#            chat = Chat(pairs, reflections)
#            chat.converse()
def response(user_response):
    robo_response=''
    sent_tokens.append(user_response)
    TfidfVec = TfidfVectorizer(tokenizer=LemNormalize, stop_words='english')
#    print("TfidfVec",TfidfVec)
    tfidf = TfidfVec.fit_transform(sent_tokens)
#    print("tfidf","tfidf")
    vals = cosine_similarity(tfidf[-1], tfidf)
    idx=vals.argsort()[0][-2]
    flat = vals.flatten()
    flat.sort()
    req_tfidf = flat[-2]
    if(req_tfidf==0):
        eliza_chat()
        robo_response="I am learning this"
#        robo_response=robo_response+"I am sorry! I don't understand you"
        print("Robo: "+robo_response)
        speak(robo_response)
        return robo_response
    else:
        robo_response = robo_response+sent_tokens[idx]
        speak(robo_response)
        print(robo_response)
        return robo_response

flag=True
#print("ROBO: My name is Robo. I can have general conversation or can talk about AI. If you want to exit, type/say Bye!")
print('Hi, Welcome to Evalueserve Customer Experience Zone!')
speak('Hi, Welcome to Evalueserve Customer Experience Zone!')
#speak("My name is Robo. I can have general conversation or can talk about AI. If you want to exit, type/say Bye!")
#print("ROBO: Would you like to have a conversation or want to know about Artificial Intellegence ?")
#speak("Would you like to have a conversation or want to know about Artificial Intellegence ?")
print('Is this is your first visit? If yes, please create a new account. In case, you are already registered with us, please login.')
speak('Is this is your first visit? If yes, please create a new account. In case, you are already registered with us, please login.')

time.sleep(6)
print('There are 4 broad Level Solution we provide')
speak('There are 4 broad Level Solutions we provide')
print('1: Consulting\
      2: Knowledge Services\
      3: Analytics\
      4: Digital Platforms')
print("which one are you interested in ?")
speak("which one are you interested in ?")


while(flag==True):
    
    user_response = input("You :")
    user_response=user_response.lower()
#    if('Financial Services' in user_response):
#        
##        eliza_chat()
    if 'What is your name' in user_response:
        print("Hi, I am EVS Assistant, nice to meet you!")
        speak('Hi, I am EVS Assistant, nice to meet you!')
    if (user_response==''):
        print("Please say something")
        speak("Please say something")
    if(user_response!='bye'):
#        print("I am here")
        if(user_response=='thanks' or user_response=='thank you' ):
#            flag=False
            print("ROBO: You are welcome..")
            speak("You are Welcome")
        else:
            if(greeting(user_response)!=None):
#                print("yoyo I am here")
                print("ROBO: "+greeting(user_response))
#                speak(greeting(user_response))
            else:
                print("ROBO: ",end="")
#                print(response(user_response))
                response(user_response)
                sent_tokens.remove(user_response)
    else:
        flag=False
        print('Feel free to ask for a call back from one of our experts in this area.')
        speak('Feel free to ask for a call back from one of our experts in this area.')
        print("Bye! see you soon!")
        speak("Bye! see you soon!")